﻿using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml;

string filePathToOpen = @"C:\Users\kvele\Downloads\ConsoleApp1\ConsoleApp1\Files\myExcel.xlsx";

// Ask the user if they want to create a new Excel file
Console.WriteLine("Do you want to create a new Excel file? (y/n)");
string response = Console.ReadLine()?.ToLower();

if (response == "y")
{
    ExcelManager.ExcelCreator();
}

// Continue with other operations
ExcelManager.ExcelOpener(filePathToOpen);
ExcelManager.ExcelWriter(filePathToOpen);

public class ExcelManager
{
    public static void ExcelCreator()
    {
        // Prompt the user to enter the Excel file name
        Console.WriteLine("Enter Excel file name (Press Enter to save as 'myExcel.xlsx' in the 'Files' directory):");
        var fileName = Console.ReadLine();
        if (string.IsNullOrEmpty(fileName))
        {
            fileName = "myExcel.xlsx";
        }
        else if (Path.GetExtension(fileName).ToLower() != ".xlsx")
        {
            fileName += ".xlsx";
        }

        // Define the specific directory path
        var directoryPath = @"C:\Users\kvele\Downloads\ConsoleApp1\ConsoleApp1\Files";

        // Ensure the directory exists
        if (!Directory.Exists(directoryPath))
        {
            Directory.CreateDirectory(directoryPath);
        }

        // Construct the full file path
        var filePath = Path.Combine(directoryPath, fileName);

        // Create and save the Excel file if it doesn't exist
        if (!File.Exists(filePath))
        {
            using (SpreadsheetDocument document = SpreadsheetDocument.Create(filePath, SpreadsheetDocumentType.Workbook))
            {
                WorkbookPart workbookPart = document.AddWorkbookPart(); // Workbook Container
                workbookPart.Workbook = new Workbook(); // Workbook Object
                WorksheetPart worksheetPart = workbookPart.AddNewPart<WorksheetPart>(); // New Worksheet
                worksheetPart.Worksheet = new Worksheet(new SheetData()); // Sheet Data
                Sheets sheets = workbookPart.Workbook.AppendChild(new Sheets()); // Sheets Collection
                Sheet sheet = new Sheet() { Id = workbookPart.GetIdOfPart(worksheetPart), SheetId = 1, Name = "Sheet 1" }; // Sheet
                sheets.Append(sheet); // Append Sheet
                workbookPart.Workbook.Save(); // Save Workbook
            }

            Console.WriteLine($"Excel file saved at: {filePath}");
        }
        else
        {
            Console.WriteLine($"File already exists at: {filePath}");
        }
    }

    public static void ExcelOpener(string filePath)
    {
        // Check if the file exists
        if (!File.Exists(filePath))
        {
            Console.WriteLine($"Excel file not found at: {filePath}");
            return;
        }

        // Open the existing Excel file
        using (SpreadsheetDocument doc = SpreadsheetDocument.Open(filePath, false))
        {
            WorkbookPart workbookPart = doc.WorkbookPart;
            Sheet sheet = workbookPart.Workbook.Descendants<Sheet>().FirstOrDefault();
            if (sheet == null)
            {
                Console.WriteLine("No sheet found in Excel file.");
                return;
            }

            WorksheetPart worksheetPart = (WorksheetPart)workbookPart.GetPartById(sheet.Id);
            if (worksheetPart == null)
            {
                Console.WriteLine("Failed to open worksheet in Excel file.");
                return;
            }

            SheetData sheetData = worksheetPart.Worksheet.Elements<SheetData>().FirstOrDefault();
            if (sheetData == null)
            {
                Console.WriteLine("No sheet data found in Excel file.");
                return;
            }

            if (!sheetData.Elements<Row>().Any())
            {
                Console.WriteLine("Current Excel file is empty");
            }
            else
            {
                Console.WriteLine("File content: ");
                foreach (Row row in sheetData.Elements<Row>())
                {
                    foreach (Cell cell in row.Elements<Cell>())
                    {
                        string text = cell.CellValue?.Text;
                        Console.Write(text + "\t");
                    }
                    Console.WriteLine();
                }
            }
        }
    }

    public static void ExcelWriter(string filePath)
    {
        Console.WriteLine("\nWould you like to add a new row? (y/n)");
        var response = Console.ReadLine();

        if (response.ToLower() == "y")
        {
            Console.WriteLine("Enter data separated by commas (e.g.,1,John,Doe):");
            string[] rowData = Console.ReadLine()!.Split(',');

            using (SpreadsheetDocument doc = SpreadsheetDocument.Open(filePath, true))
            {
                WorkbookPart workbookPart = doc.WorkbookPart;
                Sheet sheet = workbookPart.Workbook.Descendants<Sheet>().First();
                WorksheetPart worksheetPart = (WorksheetPart)workbookPart.GetPartById(sheet.Id);
                SheetData sheetData = worksheetPart.Worksheet.Elements<SheetData>().First();

                Row newRow = new Row();
                foreach (string cellData in rowData)
                {
                    Cell cell = new Cell()
                    {
                        DataType = CellValues.String,
                        CellValue = new CellValue(cellData)
                    };
                    newRow.Append(cell);
                }
                sheetData.Append(newRow);
            }
        }
        Console.WriteLine("Excel was closed.");
    }
}
