﻿using SpreadsheetLight;
using System.Data;

var excelFileGenerator = new ExcelFileGenerator();
excelFileGenerator.GenerateExcelFile();

public class ExcelFileGenerator
{
    public void GenerateExcelFile()
    {
        try
        {
            // Constructing file path to save in Downloads directory
            string downloadsPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            string filePath = Path.Combine(downloadsPath, "Downloads", "excel.xlsx");

            SLDocument oSLDocument = new SLDocument();
            DataTable table = new DataTable();

            table.Columns.Add("Id", typeof(int));
            table.Columns.Add("Name", typeof(string));
            table.Columns.Add("Price", typeof(double));

            table.Rows.Add(1, "Laptop", 1000.0);
            table.Rows.Add(2, "Mouse", 20.0);
            table.Rows.Add(3, "Keyboard", 50.0);

            oSLDocument.ImportDataTable(1, 1, table, true);
            oSLDocument.SaveAs(filePath);

            Console.WriteLine($"Excel file saved successfully at: {filePath}");

            var file = new SLDocument(filePath);
            int index = 1;

            while(!string.IsNullOrEmpty(file.GetCellValueAsString(index, 1)))
            {
                Console.WriteLine($"Id: {file.GetCellValueAsInt32(index, 1)}");
                Console.WriteLine($"Name: {file.GetCellValueAsString(index, 2)}");
                Console.WriteLine($"Price: {file.GetCellValueAsDouble(index, 3)}");
                index++;

                //int id = file.GetCellValueAsInt32(index, 1);
                //string name = file.GetCellValueAsString(index, 2);
                //double price = file.GetCellValueAsDouble(index, 3);
                //Console.WriteLine($"{id} {name} {price}");
                //index++;
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error saving Excel file: " + ex.Message);
        }
    }
}
